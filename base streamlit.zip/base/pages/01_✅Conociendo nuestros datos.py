import pandas as pd
import streamlit as st

areas =  pd.read_csv('area_protegida.csv')
st.title("Parte 1")
st.header("Datos que encontraron")
filas, columnas = areas.shape
with st.expander("¿Cuántas filas y columnas tiene el dataset?"):
    filas, columnas = areas.shape
    st.write(f'Tiene { filas} filas y {columnas} columnas')
    
    
filtr2 = areas["jap"].value_counts()


with st.expander("1.calculo: de todas las areas de jurisdiccion jap, cual es su subtipo mas frecuente?"):
    st.write(filtr2)


        