import streamlit as st
import pandas as pd

import streamlit as st
import plotly.express as px


areas = pd.read_csv('area_protegida.csv')
st.title("Gráfico")

filtr3 = areas["tap"].value_counts()
fig = px.bar(
    data_frame = filtr3, x = filtr3.index, y = filtr3.values, title = "grafico con la frecuencia de los subtipo jurisdccion")

# Mostrar el gráfico
st.plotly_chart(fig)
